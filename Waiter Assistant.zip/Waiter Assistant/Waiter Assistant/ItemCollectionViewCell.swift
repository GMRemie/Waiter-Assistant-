//
//  ItemCollectionViewCell.swift
//  Waiter Assistant
//
//  Created by Joseph Storer on 1/27/19.
//  Copyright © 2019 Joseph Storer. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var label_name: UILabel!
    @IBOutlet weak var delete_button: UIButton!
    
    
}
