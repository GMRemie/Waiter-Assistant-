//
//  Extension_MenuListViewController.swift
//  Waiter Assistant
//
//  Created by Joseph Storer on 1/25/19.
//  Copyright © 2019 Joseph Storer. All rights reserved.
//

import Foundation
import UIKit
import Firebase

extension MenuListViewController{
    
    // firebase references
    
    func RefreshCollection(){
        
    }
    
    
    
    
}


